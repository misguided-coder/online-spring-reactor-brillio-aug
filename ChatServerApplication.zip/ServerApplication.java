package com.example.concurrency;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


class UserThreadFactory implements ThreadFactory{
	
	@Override
	public Thread newThread(Runnable r) {
	
		Thread thread=new Thread(r);
		thread.setName("UserPoolThread");
		
		return thread;
	}
}

public class ServerApplication {
	
	ConcurrentHashMap<String,Integer> clientAddressPortList=new ConcurrentHashMap<String, Integer>();

	Logger logger=LoggerFactory.getLogger(ServerApplication.class);
	
	public ServerApplication() {
			
		ExecutorService executorService=Executors.newFixedThreadPool(1000,new UserThreadFactory());
		
		try {
			ServerSocket serverSocket=new ServerSocket(4000);
			System.out.println("Server is up....");
			logger.debug("Server is up....");
			
			while(true){
		
				System.out.println("Waiting for client connection....");
				logger.debug("Waiting for client connection....");

				Socket client= serverSocket.accept();
				clientAddressPortList.put(client.getInetAddress().getHostName(), client.getPort());
				System.out.println("Client connection is accepted....");

				ClientHandler clientHandler=new ClientHandler(client);
				executorService.execute(clientHandler);
				System.out.println("Client socket is assigned to pool...");
				
				//new Thread(clientHandler).start();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	
	public static void main(String s[]){
		new ServerApplication();
		
	}
	
}


class ClientHandler implements Runnable{
	
	Socket socket;
	
	public ClientHandler(Socket socket) {
		this.socket=socket;
	}
	
	@Override
	public void run() {
	
		readFromSocket();
		writeToSocket();
	}
	
	public void readFromSocket(){
		try {
			InputStream inputStream=socket.getInputStream();
			inputStream.read();
			//Do some work
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	public void writeToSocket(){
		try {
			OutputStream outputStream=socket.getOutputStream();
			outputStream.write("Welcome to server".getBytes());
			//Do some work
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}